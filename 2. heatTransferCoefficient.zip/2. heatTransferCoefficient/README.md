1. Change the default settings and parameters of heat exchanger to your own case.
2. Run the `main.py` script by the command:

```
python main.py
```